BOLD v.2 - Responsive CV/Resume
---------------------------------------------------------------------------

Thank you for buying the BOLD v.2 template!

You will find the help files inside the "_documentation" folder.

If you need further assistance feel free to contact QBKL on the profile page: http://themeforest.net/user/QBKL

If you like this template, please consider giving it a comment and/or a rating!

Thank you once again,

The QBKL Studio team

Version: 2.0
Release date: 21 August, 2013